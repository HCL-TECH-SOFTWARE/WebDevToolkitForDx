# Web Developer Dashboard for HCL Digital Experience

This package provides the dashboard user interface support for the Web Developer Toolkit for HCL Digital Experience. For more information, see the README.md file of the toolkit.

