
# HCL Digital Experience Script Portlets

# Using the digexp-sp-cmd command line utility
Note that all the functionality for push/pull of script portlets is available from the Dashboard user interface. For the command line support, use:
```
$ sp <command> [options]
```

## Configuration

The application uses the following sequence of preference when it processes these options:

### Show help info:

```bash
sp help
sp help_en
sp usage_en
```

### List command:

```bash
sp list projects
sp list vportals
sp list siteareas
```

### Push command:

```bash
sp push -contentRoot <src-dir> -wcmContentName <content-name>
sp push -prebuiltZip <src-zip> -wcmContentName <content-name>
```

The log file **sp-cmdln.log** is created under current directory when `-contentRoot` option isn't present. When  `-contentRoot` option is given, the **sp-cmdln.log** is created under that content root folder.

### Pull command:

```bash
sp pull -contentRoot <src-dir>
```

## Support

The supported options are same as existing Java application. Refer to https://help.hcltechsw.com/digital-experience/8.5/script-portlet/cmd_line_push_cmd.html#cmd_line_push_cmd__table_gqy_kkr_2s for details.

In case of any more questions or issues please raise via Issues tab in this github repository. HCL Support will make every reasonable effort to assist in problem resolution of any issues found in this software.
