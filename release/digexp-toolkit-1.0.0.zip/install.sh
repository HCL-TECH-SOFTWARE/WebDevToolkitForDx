cd packs
npm install -g wcm-design.tar.gz
npm install -g --use-pre-compiled dashboard.tar.gz
npm install -g nw@0.42.0
